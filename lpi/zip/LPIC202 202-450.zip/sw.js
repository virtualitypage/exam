const resources = ["https://quizgenerator.net/quizgen5.15.1/basic/photoswipe/default-skin/default-skin.png","https://quizgenerator.net/quizgen5.15.1/basic/photoswipe/default-skin/default-skin.svg","https://quizgenerator.net/quizgen5.15.1/basic/photoswipe/default-skin/preloader.gif","https://quizgenerator.net/quizgen5.15.1/basic/get.mp3","https://quizgenerator.net/quizgen5.15.1/basic/move.mp3","https://quizgenerator.net/quizgen5.15.1/basic/koke.mp3","https://quizgenerator.net/quizgen5.15.1/basic/js/mdb.js","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/MathJax.js?config=TeX-MML-AM_SVG","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/element/mml/optable/BasicLatin.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/extensions/TeX/mathchoice.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/element/mml/optable/MathOperators.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/element/mml/optable/SuppMathOperators.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/element/mml/optable/CombDiactForSymbols.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/extensions/TeX/boldsymbol.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/element/mml/optable/GeneralPunctuation.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/element/mml/optable/Latin1Supplement.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/jax.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/fontdata.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/Size1/Regular/Main.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/autoload/mtable.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/AMS/Regular/Main.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/AMS/Regular/MathOperators.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/Main/Regular/SuppMathOperators.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/AMS/Regular/SuppMathOperators.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/Main/Regular/CombDiacritMarks.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/Main/Regular/LetterlikeSymbols.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/Main/Regular/BasicLatin.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/Main/Italic/Main.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/Main/Italic/CombDiacritMarks.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/Size3/Regular/Main.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/Size2/Regular/Main.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/AMS/Regular/MiscTechnical.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/Size4/Regular/Main.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/Main/Regular/GeometricShapes.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/AMS/Regular/GeometricShapes.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/AMS/Regular/GeneralPunctuation.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/Main/Regular/GreekAndCoptic.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/Math/BoldItalic/Main.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/Main/Bold/Main.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/Main/Regular/MiscSymbols.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/Typewriter/Regular/Main.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/Typewriter/Regular/BasicLatin.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/SansSerif/Regular/Main.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/SansSerif/Regular/BasicLatin.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/Caligraphic/Regular/Main.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/Main/Bold/BasicLatin.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/Main/Italic/BasicLatin.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/Script/Regular/Main.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/Script/Regular/BasicLatin.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/Fraktur/Regular/Main.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/Fraktur/Regular/BasicLatin.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/Main/Italic/GreekAndCoptic.js?V=2.7.1","https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/jax/output/SVG/fonts/TeX/AMS/Regular/Latin1Supplement.js?V=2.7.1"];
const cacheName = 'quizgen-cache-v1';

const deleteCaches = async () => {
  const keys = await caches.keys();
  return Promise.all(keys.map((key) => {
    return caches.delete(key);
  }));
}

const precacheResources = async () => {
  const cache = await caches.open(cacheName);
  return Promise.all(resources.map(async (resource) => {
    const response = await fetch(resource);
    if (response.status !== 206) {
      return cache.put(resource, response.clone());
    }
    // フルサイズでないレスポンスの場合はキャッシュせずに終了
    if (!isFullSizeRangeResponse(response.clone())) {
      console.log('Precache failed. Partial content cannnot be cached. Response URL:' + response.url);
      return;
    }
    // 動画や音声の場合にFireFoxだとstatus 206のRange Responseが返ってくることがあるが、そのままキャッシュしようとするとCashe APIの仕様上エラーとなる
    // データとしては完全なデータが返ってきているのでstatus 200の通常のResponseに置換してキャッシュ
    const blob = await response.blob();
    const newResponse = new Response(blob, {status: 200, statusText: 'OK', headers: response.headers});
    return cache.put(newResponse.url, newResponse.clone());
  }));
}

const isFullSizeRangeResponse = (response) => {
  if (response.status !== 206) {
    return false;
  }
  const contentRangeHeader = response.headers.get('Content-Range');
  if (!contentRangeHeader) {
    return false;
  }
  const contentRangeParts = /(\d*)-(\d*)\/(\d*)/.exec(contentRangeHeader);
  if (!contentRangeParts[1] || !contentRangeParts[2] || !contentRangeParts[3]) {
    return false;
  }
  return +contentRangeParts[3] === +contentRangeParts[2] - contentRangeParts[1] + 1;
}

const handleRequest = async (request) => {
  const cache = await caches.open(cacheName);
  const cacheResponse = await cache.match(request.url);
  if (!cacheResponse) {
    return fetch(request.clone());
  }
  if (request.headers.get('range')) {
    return createPartialResponse(request.clone(), cacheResponse.clone());
  }
  return cacheResponse;
}

// ref: https://github.com/GoogleChrome/workbox/tree/v6/packages/workbox-range-requests
const createPartialResponse = async (request, originalResponse) => {
  try {
    if (originalResponse.status === 206) {
      return originalResponse;
    }
    const rangeHeader = request.headers.get('range');
    if (!rangeHeader) {
      throw new Error('no-range-header');
    }
    const boundaries = parseRangeHeader(rangeHeader);
    const originalBlob = await originalResponse.blob();
    const effectiveBoundaries = calculateEffectiveBoundaries(originalBlob, boundaries.start, boundaries.end);
    const slicedBlob = originalBlob.slice(effectiveBoundaries.start, effectiveBoundaries.end);
    const slicedBlobSize = slicedBlob.size;
    const slicedResponse = new Response(slicedBlob, {
      // Status code 206 is for a Partial Content response.
      // See https://developer.mozilla.org/en-US/docs/Web/HTTP/Status/206
      status: 206,
      statusText: 'Partial Content',
      headers: originalResponse.headers,
    });
    slicedResponse.headers.set('Content-Length', String(slicedBlobSize));
    slicedResponse.headers.set('Content-Range', `bytes ${effectiveBoundaries.start}-${effectiveBoundaries.end - 1}/${originalBlob.size}`);
    return slicedResponse;
  } catch (error) {
    return new Response('', {
      status: 416,
      statusText: 'Range Not Satisfiable',
    });
  }
}

const parseRangeHeader = (rangeHeader) => {
  const normalizedRangeHeader = rangeHeader.trim().toLowerCase();
  const rangeParts = /(\d*)-(\d*)/.exec(normalizedRangeHeader);
  if (!rangeParts || !(rangeParts[1] || rangeParts[2])) {
    throw new Error('invalid-range-values');
  }
  return {
    start: rangeParts[1] === '' ? undefined : Number(rangeParts[1]),
    end: rangeParts[2] === '' ? undefined : Number(rangeParts[2]),
  };
}

const calculateEffectiveBoundaries = (blob, start, end) => {
  const blobSize = blob.size;
  if ((end && end > blobSize) || (start && start < 0)) {
    throw new Error('range-not-satisfiable');
  }
  let effectiveStart;
  let effectiveEnd;
  if (start !== undefined && end !== undefined) {
    effectiveStart = start;
    // Range values are inclusive, so add 1 to the value.
    effectiveEnd = end + 1;
  } else if (start !== undefined && end === undefined) {
    effectiveStart = start;
    effectiveEnd = blobSize;
  } else if (end !== undefined && start === undefined) {
    effectiveStart = blobSize - end;
    effectiveEnd = blobSize;
  }
  return {
    start: effectiveStart,
    end: effectiveEnd,
  };
}

self.addEventListener('install', async (event) => {
  self.skipWaiting();
  // キャッシュを一旦削除してからキャッシュを追加
  await deleteCaches();
  await precacheResources();
  console.log('Precache process finished.');
});

self.addEventListener('activate', async (event) => {
  await clients.claim();
});

// リクエストを監視
self.addEventListener('fetch', (event) => {
  event.respondWith(handleRequest(event.request));
});
